import React from 'react'

export default function Index(props) {
    return (<div className="button-loader"><div className="clockloader"></div></div>)
}
