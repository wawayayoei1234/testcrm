export const buttontext =[
    {
        "text" : "Next"
    }
]