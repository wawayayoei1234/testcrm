export const themedata = [
    {
        "primary": "#84BAA1",
        "secondary": "#48846B",
        "three"  : "#ffffff",
        "four":"#7F8391",
        "five"  : "#52752F",
        "six"  : "#307BF1",
        "seven"  : "#EBEBEB",
        "eight"  : "'#666666'",
        "nine"  : "'#97BDFE'",
        "ten"  : "#171717",
        "eleven"  : "#9CD6B3",
        "twelve"  : "#D9D9D9",
        "bgshadowwhite":"#FFFBE2",
        "greenlight":"#90BA61",
        "greenblack":"#44612A"
    }
];