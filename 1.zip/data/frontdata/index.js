export const frontdata = [
    {
        "font": "var(--cooper-font)"
    }
];